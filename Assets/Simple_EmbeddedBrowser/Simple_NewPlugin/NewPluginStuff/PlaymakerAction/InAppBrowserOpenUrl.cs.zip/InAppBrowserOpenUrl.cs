﻿using System.Collections.Generic;
using UnityEngine;

namespace HutongGames.PlayMaker.Actions
{
	[ActionCategory("InAppBrowser")]
	[Tooltip("Open a URl using InAppBrowser")]
	public class InAppBrowserOpenURL : FsmStateAction
	{
		[RequiredField]
		[Tooltip("URL")]
		public FsmString address;

	

	public override void Reset()
	{
		address = null;

	}

	public override void OnEnter()
	{
		DoEnter();
		Finish();
	}

	private void DoEnter()
	{
		InAppBrowser.OpenURL(address.Value);
	}
	}
}